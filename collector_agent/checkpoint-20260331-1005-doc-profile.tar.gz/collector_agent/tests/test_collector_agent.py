from __future__ import annotations

import asyncio

import httpx

from collector_agent.config import Settings
from collector_agent.contracts import CollectorRequest, CollectorResponse, Provenance, Quality, SourceResult, TargetRef
from collector_agent.http_app import app
from collector_agent.rules import build_agent_diagnostics, classify_asset
from collector_agent.service import CollectorAgentService
from collector_agent.sources import build_default_adapters


def _request_payload(**overrides):
    payload = {
        "target": {
            "name": "Bitcoin",
            "ticker": "BTC",
            "coingecko_id": "bitcoin",
        },
        "sources": ["coingecko", "defillama"],
        "criteria": {
            "need_metrics": True,
            "need_protocol": True,
            "need_yields": False,
            "need_competitors": False,
        },
        "strategy": "api_first_browser_second",
        "deadline_sec": 5,
    }
    payload.update(overrides)
    return payload


async def _app_post(payload: dict, *, headers: dict[str, str] | None = None) -> httpx.Response:
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        return await client.post("/collect", json=payload, headers=headers)


class _FakeService:
    def __init__(self, response: CollectorResponse) -> None:
        self.response = response

    async def collect(self, request: CollectorRequest) -> CollectorResponse:
        assert request.target.name == "Bitcoin"
        return self.response


class _NoopAsyncClient:
    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _StaticAdapter:
    def __init__(self, result: SourceResult) -> None:
        self.result = result

    async def collect(self, request: CollectorRequest, *, client, deadline_at: float) -> SourceResult:
        del request, client, deadline_at
        return self.result


class _SlowAdapter:
    def __init__(self, source_name: str, delay: float) -> None:
        self.source_name = source_name
        self.delay = delay

    async def collect(self, request: CollectorRequest, *, client, deadline_at: float) -> SourceResult:
        del request, client, deadline_at
        await asyncio.sleep(self.delay)
        return _success_result(self.source_name, metrics={"price_usd": 1.0})


class _ErrorAdapter:
    def __init__(self, exc: Exception) -> None:
        self.exc = exc

    async def collect(self, request: CollectorRequest, *, client, deadline_at: float) -> SourceResult:
        del request, client, deadline_at
        raise self.exc


def _success_result(source: str, *, metrics=None, items=None, metadata=None) -> SourceResult:
    return SourceResult(
        source=source,
        method="api",
        elapsed_ms=0,
        success=True,
        metrics=metrics,
        items=items,
        metadata=metadata,
        provenance=Provenance(method="api", provider=source),
        quality=Quality(status="complete", confidence=0.9, stale=False),
    )


def test_auth_ok(monkeypatch):
    response = CollectorResponse(
        status="ok",
        target=TargetRef(name="Bitcoin", ticker="BTC", coingecko_id="bitcoin"),
        collected_at="2026-03-30T12:00:00Z",
        source_results=[],
    )
    monkeypatch.setattr(
        "collector_agent.http_app.get_settings",
        lambda: Settings(
            service_token="secret",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
    )
    monkeypatch.setattr("collector_agent.http_app.get_service", lambda: _FakeService(response))

    http_response = asyncio.run(
        _app_post(
            _request_payload(),
            headers={"X-Service-Token": "secret"},
        )
    )

    assert http_response.status_code == 200
    assert http_response.json()["status"] == "ok"


def test_auth_fail(monkeypatch):
    monkeypatch.setattr(
        "collector_agent.http_app.get_settings",
        lambda: Settings(
            service_token="secret",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
    )
    monkeypatch.setattr("collector_agent.http_app.get_service", lambda: None)

    http_response = asyncio.run(
        _app_post(
            _request_payload(),
            headers={"X-Service-Token": "wrong"},
        )
    )

    body = http_response.json()
    assert http_response.status_code == 401
    assert body["status"] == "error"
    assert body["errors"][0]["code"] == "unauthorized"


def test_invalid_request_returns_structured_error(monkeypatch):
    monkeypatch.setattr(
        "collector_agent.http_app.get_settings",
        lambda: Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
    )
    monkeypatch.setattr("collector_agent.http_app.get_service", lambda: None)

    http_response = asyncio.run(
        _app_post(
            _request_payload(target={"ticker": "BTC"}),
        )
    )

    body = http_response.json()
    assert http_response.status_code == 400
    assert body["status"] == "error"
    assert body["errors"][0]["code"] == "invalid_request"
    assert body["source_results"] == []


def test_valid_request_ok_with_real_http_mocks():
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/coins/bitcoin":
            return httpx.Response(
                200,
                json={
                    "id": "bitcoin",
                    "symbol": "btc",
                    "name": "Bitcoin",
                    "description": {"en": "Digital gold"},
                    "categories": ["Store of Value"],
                    "asset_platform_id": None,
                    "platforms": {},
                    "links": {
                        "homepage": ["https://bitcoin.org"],
                        "twitter_screen_name": "bitcoin",
                        "telegram_channel_identifier": "",
                        "subreddit_url": "https://reddit.com/r/bitcoin",
                        "repos_url": {"github": ["https://github.com/bitcoin/bitcoin"]},
                    },
                    "community_data": {"twitter_followers": 10, "reddit_subscribers": 20},
                    "market_data": {
                        "current_price": {"usd": 100000},
                        "market_cap": {"usd": 2_000_000_000_000},
                        "total_volume": {"usd": 50_000_000_000},
                        "price_change_percentage_24h": 3.2,
                        "price_change_percentage_7d": 7.1,
                        "fully_diluted_valuation": {"usd": 2_100_000_000_000},
                        "circulating_supply": 19_800_000,
                    },
                },
            )
        if request.url.path == "/protocol/bitcoin":
            return httpx.Response(
                200,
                json={
                    "slug": "bitcoin",
                    "name": "Bitcoin",
                    "category": "Chain",
                    "chains": ["Bitcoin"],
                    "url": "https://bitcoin.org",
                    "description": "Bitcoin protocol",
                    "tvl": 123456789,
                    "mcap": 2_000_000_000_000,
                    "fdv": 2_100_000_000_000,
                    "volume24h": 100_000_000,
                },
            )
        raise AssertionError(f"Unexpected request: {request.method} {request.url}")

    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters=build_default_adapters(
            Settings(
                service_token="",
                http_timeout_seconds=10,
                coingecko_base_url="https://cg.example",
                defillama_base_url="https://dl.example",
            )
        ),
        client_factory=lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler), timeout=None),
    )

    response = asyncio.run(service.collect(CollectorRequest.model_validate(_request_payload())))

    assert response.status == "ok"
    assert len(response.source_results) == 2
    assert response.source_results[0].metrics["price_usd"] == 100000
    assert response.source_results[1].metrics["tvl"] == 123456789
    assert response.diagnostics["asset_type"] == "blockchain"
    assert "tvl" in response.diagnostics["found_metrics"]
    assert "active_addresses" in response.diagnostics["unavailable_until_dune"]
    cg_item = response.source_results[0].items[0]
    dl_item = response.source_results[1].items[0]
    assert cg_item["content_type"] == "metric"
    assert dl_item["content_type"] == "protocol_data"
    assert cg_item["metadata"]["official_links"]["github"] == "https://github.com/bitcoin/bitcoin"
    assert dl_item["metadata"]["website"] == "https://bitcoin.org"


def test_partial_when_one_source_fails():
    request = CollectorRequest.model_validate(_request_payload())
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters={
            "coingecko": _StaticAdapter(_success_result("coingecko", metrics={"price_usd": 100000.0})),
            "defillama": _ErrorAdapter(
                httpx.ConnectError("boom", request=httpx.Request("GET", "https://dl.example/protocol/bitcoin"))
            ),
        },
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))

    assert response.status == "partial"
    assert response.source_results[0].success is True
    assert response.source_results[1].success is False
    assert response.source_results[1].error.code == "upstream_transport_error"
    assert response.diagnostics["asset_type"] == "unknown_other"


def test_timeout_deadline_behavior():
    request = CollectorRequest.model_validate(_request_payload(deadline_sec=0.01))
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters={
            "coingecko": _StaticAdapter(_success_result("coingecko", metrics={"price_usd": 100000.0})),
            "defillama": _SlowAdapter("defillama", delay=0.05),
        },
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))

    assert response.status == "partial"
    timed_out = response.source_results[1]
    assert timed_out.success is False
    assert timed_out.timed_out is True
    assert timed_out.error.code == "timeout"


def test_upstream_api_failure_returns_error_without_crash():
    request = CollectorRequest.model_validate(
        _request_payload(
            sources=["coingecko"],
            criteria={
                "need_metrics": True,
                "need_protocol": True,
                "need_yields": False,
                "need_competitors": False,
            },
        )
    )
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters={
            "coingecko": _ErrorAdapter(
                httpx.HTTPStatusError(
                    "bad gateway",
                    request=httpx.Request("GET", "https://cg.example/coins/bitcoin"),
                    response=httpx.Response(503),
                )
            )
        },
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))

    assert response.status == "error"
    assert response.errors[0].code == "upstream_http_error"
    assert response.source_results[0].success is False


def test_dune_placeholder_is_extension_point():
    request = CollectorRequest.model_validate(
        _request_payload(
            sources=["dune"],
            criteria={
                "need_metrics": True,
                "need_protocol": True,
                "need_yields": False,
                "need_competitors": False,
            },
        )
    )
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters=build_default_adapters(
            Settings(
                service_token="",
                http_timeout_seconds=10,
                coingecko_base_url="https://cg.example",
                defillama_base_url="https://dl.example",
            )
        ),
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))

    assert response.status == "error"
    assert response.source_results[0].error.code == "not_implemented"
    assert response.diagnostics["unavailable_until_dune"]


def test_rule_layer_classifies_lending_and_builds_metric_plan():
    request = CollectorRequest.model_validate(
        _request_payload(
            sources=["defillama"],
            target={"name": "Aave", "ticker": "AAVE", "coingecko_id": "aave"},
        )
    )
    result = _success_result(
        "defillama",
        metrics={"tvl": 1_500_000_000.0},
        metadata={"category": "Lending", "chains": ["Ethereum", "Base"]},
        items=[
            {
                "metadata": {
                    "yield_pool": True,
                }
            },
            {
                "metadata": {
                    "competitors": [
                        {"name": "Compound", "tvl": 800_000_000.0},
                        {"name": "Spark", "tvl": 700_000_000.0},
                    ],
                    "target_snapshot": {"tvl": 1_500_000_000.0},
                }
            },
        ],
    )

    classification = classify_asset(request, [result])
    diagnostics = build_agent_diagnostics(request, [result])

    assert classification.asset_type == "lending"
    assert diagnostics["source_priority"] == ["defillama", "future:dune"]
    assert diagnostics["required_metrics_attempted"] == [
        "tvl",
        "yields",
        "fees",
        "revenue",
        "market_share",
        "competitors",
    ]
    assert "tvl" in diagnostics["found_metrics"]
    assert "yields" in diagnostics["found_metrics"]
    assert "competitors" in diagnostics["found_metrics"]
    assert "market_share" in diagnostics["found_metrics"]
    assert "deposits" in diagnostics["unavailable_until_dune"]
    assert "borrows" in diagnostics["unavailable_until_dune"]
    assert "fees" in diagnostics["not_found_metrics"]


def test_rule_layer_avoids_false_dex_match_from_index_categories():
    request = CollectorRequest.model_validate(
        _request_payload(
            sources=["coingecko", "defillama"],
            target={"name": "Aave", "ticker": "AAVE", "coingecko_id": "aave"},
        )
    )
    coingecko_result = _success_result(
        "coingecko",
        metrics={"market_cap": 1_400_000_000.0},
        metadata={
            "categories": [
                "Index Coop Defi Index",
                "Coinbase 50 Index",
                "Lending/Borrowing Protocols",
            ]
        },
        items=[
            {
                "title": "Aave — CoinGecko",
                "content": "Aave is a decentralized money market protocol where users can lend and borrow assets.",
                "metadata": {
                    "categories": [
                        "Index Coop Defi Index",
                        "Lending/Borrowing Protocols",
                    ]
                },
            }
        ],
    )
    defillama_result = _success_result(
        "defillama",
        metrics={"tvl": 23_000_000_000.0},
        metadata={"category": None},
        items=[{"metadata": {"yield_pool": True}}],
    )

    classification = classify_asset(request, [coingecko_result, defillama_result])

    assert classification.asset_type == "lending"
    assert classification.scores["dex"] < classification.scores["lending"]


def test_rule_layer_unknown_other_on_low_confidence_hints():
    request = CollectorRequest.model_validate(
        _request_payload(
            target={"name": "Mystery Protocol", "ticker": "MYS"},
            sources=["coingecko"],
        )
    )
    result = _success_result(
        "coingecko",
        metrics={"price_usd": 1.0},
        metadata={"categories": ["Experimental"]},
        items=[{"metadata": {"categories": ["Experimental"]}}],
    )

    classification = classify_asset(request, [result])
    diagnostics = build_agent_diagnostics(request, [result])

    assert classification.asset_type == "unknown_other"
    assert diagnostics["asset_type"] == "unknown_other"
    assert diagnostics["found_metrics"] == []


def test_rule_layer_marks_perp_dex_dune_gap_honestly():
    request = CollectorRequest.model_validate(
        _request_payload(
            target={"name": "Hyperliquid", "ticker": "HYPE", "coingecko_id": "hyperliquid"},
            sources=["defillama"],
        )
    )
    result = _success_result(
        "defillama",
        metrics={"volume_24h": 900_000_000.0},
        metadata={"category": "Derivatives"},
        items=[
            {
                "metadata": {
                    "competitors": [{"name": "dYdX", "volume_24h": 300_000_000.0}],
                    "target_snapshot": {"volume_24h": 900_000_000.0},
                }
            }
        ],
    )

    diagnostics = build_agent_diagnostics(request, [result])

    assert diagnostics["asset_type"] == "perp_dex"
    assert "trading_volume" in diagnostics["found_metrics"]
    assert "market_share" in diagnostics["found_metrics"]
    assert "open_interest" in diagnostics["unavailable_until_dune"]
    assert "active_traders" in diagnostics["unavailable_until_dune"]
    assert "fees" in diagnostics["not_found_metrics"]


def test_service_keeps_response_shape_and_agent_diagnostics():
    request = CollectorRequest.model_validate(_request_payload())
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters={
            "coingecko": _StaticAdapter(
                _success_result(
                    "coingecko",
                    metrics={"price_usd": 100000.0, "market_cap": 2_000_000_000_000.0},
                    metadata={"categories": ["Layer 1", "Store of Value"]},
                    items=[{"metadata": {"categories": ["Layer 1", "Store of Value"]}}],
                )
            ),
            "defillama": _StaticAdapter(
                _success_result(
                    "defillama",
                    metrics={"tvl": 123456789.0},
                    metadata={"category": "Chain", "chains": ["Bitcoin"]},
                    items=[{"metadata": {"chains": ["Bitcoin"]}}],
                )
            ),
        },
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))
    payload = response.model_dump(mode="json")

    assert payload["status"] == "ok"
    assert "source_results" in payload
    assert "diagnostics" in payload
    assert payload["diagnostics"]["asset_type"] == "blockchain"
    assert payload["diagnostics"]["by_metric"]["tvl"]["status"] == "found"


def test_service_diagnostics_survive_partial_missing_data():
    request = CollectorRequest.model_validate(_request_payload())
    service = CollectorAgentService(
        settings=Settings(
            service_token="",
            http_timeout_seconds=10,
            coingecko_base_url="https://cg.example",
            defillama_base_url="https://dl.example",
        ),
        adapters={
            "coingecko": _StaticAdapter(
                _success_result(
                    "coingecko",
                    metrics={"price_usd": 2.0},
                    metadata={"categories": ["Oracle"]},
                    items=[{"metadata": {"categories": ["Oracle"]}}],
                )
            ),
            "defillama": _StaticAdapter(
                SourceResult(
                    source="defillama",
                    method="api",
                    elapsed_ms=0,
                    success=False,
                    error={"code": "target_not_found", "message": "missing", "retryable": False},
                    metadata={"category": None},
                    provenance=Provenance(method="api", provider="defillama"),
                    quality=Quality(status="warnings", confidence=0.3, stale=False),
                )
            ),
        },
        client_factory=_NoopAsyncClient,
    )

    response = asyncio.run(service.collect(request))

    assert response.status == "partial"
    assert response.diagnostics["asset_type"] == "infrastructure_or_oracle_or_data"
    assert "competitors" in response.diagnostics["not_found_metrics"]
